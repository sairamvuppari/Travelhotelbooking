$(function () {
    var date1 = $('#date1');
    var date2 = $('#date2');
    date1.datepicker({
        defaultDate: "+1w",
        changeMonth: true,
        numberOfMonths: 1,
        onClose: function (selectedDate) {
            var date = $(this).datepicker("getDate");
            date2.datepicker("setDate", date);
            date2.datepicker("show");
        }
    });
    date2.datepicker({
        defaultDate: "+1w",
        changeMonth: true,
        numberOfMonths: 1,
        onClose: function (selectedDate) {
            var date = $(this).datepicker("getDate");
            var formattedDate = $.datepicker.formatDate('D,dd mm', date);
            date1.val(date1.datepicker({ dateFormat: "D,dd mm" }).val() + " - " + formattedDate);
        }
    });
});